package beans;

public enum FacilityType {
	GYM,
	POOL,
	SPORTCENTER,
	DANCINGSTUDIO,
	BOWLINGCENTER,
	SHOOTINGRANGE
}
