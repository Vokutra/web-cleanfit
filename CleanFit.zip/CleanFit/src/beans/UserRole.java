package beans;

public enum UserRole {
	CUSTOMER, 
	MANAGER, 
	ADMIN, 
	COACH

}
