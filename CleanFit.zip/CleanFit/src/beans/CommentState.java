package beans;

public enum CommentState {
	WAITING, 
	DENIED, 
	APPROVED

}
