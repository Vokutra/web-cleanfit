package beans;

public enum Gender {
	MALE, 
	FEMALE

}
