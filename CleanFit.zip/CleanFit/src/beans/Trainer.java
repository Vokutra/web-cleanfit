package beans;

import java.util.Date;

public class Trainer extends User{
	
	public Trainer(String username, String password, String name, String surname, Date birthdate, Gender gender,
			UserRole userRole) {
		super(username, password, name, surname, birthdate, gender, userRole);
		// TODO Auto-generated constructor stub
	}

}
